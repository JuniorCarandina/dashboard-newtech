# Dashboard New Tech
Dashboard gerencial de acompanhamento de projetos.